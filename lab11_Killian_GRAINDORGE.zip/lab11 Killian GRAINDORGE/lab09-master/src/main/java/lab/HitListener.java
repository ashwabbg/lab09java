package lab;

public interface HitListener {
	void hit();
}
